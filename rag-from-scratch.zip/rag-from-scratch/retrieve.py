def retrieve(query, model, index, text_chunks, k=2):
    query_vector = model.encode([query])
    distances, indices = index.search(query_vector, k)
    
    results = [text_chunks[i] for i in indices[0]]
    return results