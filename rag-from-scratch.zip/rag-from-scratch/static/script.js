document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input');
    const chatContainer = document.getElementById('chat-container');

    // Configure marked wrapper for safe parsing
    marked.setOptions({
        breaks: true,
        gfm: true
    });

    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const message = userInput.value.trim();
        if (!message) return;

        // Clear input
        userInput.value = '';

        // Add user message to UI
        appendMessage('user', message);

        // Show typing indicator
        const typingIndicator = showTypingIndicator();

        try {
            // Send request to API
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: message })
            });

            const data = await response.json();

            // Remove typing indicator
            typingIndicator.remove();

            if (data.answer) {
                appendMessage('system', data.answer);
            } else if (data.error) {
                appendMessage('system', `**Error**: ${data.error}`);
            }
        } catch (error) {
            typingIndicator.remove();
            appendMessage('system', `**Connection Error**: Failed to reach the neural core. Ensure the backend is running.`);
            console.error('Fetch error:', error);
        }
    });

    function appendMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        const avatarIcon = sender === 'user' ? 'fa-user' : 'fa-server';

        // Use document fragment for safer DOM manipulation
        const html = `
            <div class="message-avatar">
                <i class="fa-solid ${avatarIcon}"></i>
            </div>
            <div class="message-content">
                ${sender === 'system' ? marked.parse(text) : escapeHTML(text)}
            </div>
        `;

        messageDiv.innerHTML = html;
        chatContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    function showTypingIndicator() {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message system-message typing-container';

        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fa-solid fa-server"></i>
            </div>
            <div class="message-content">
                <div class="typing-indicator">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            </div>
        `;

        chatContainer.appendChild(messageDiv);
        scrollToBottom();
        return messageDiv;
    }

    function scrollToBottom() {
        // Use a slight timeout to ensure DOM update before scrolling
        setTimeout(() => {
            const wrapper = document.querySelector('.chat-wrapper');
            wrapper.scrollTo({
                top: wrapper.scrollHeight,
                behavior: 'smooth'
            });
        }, 50);
    }

    function escapeHTML(str) {
        let div = document.createElement('div');
        div.innerText = str;
        return div.innerHTML;
    }
});
