from fastapi import FastAPI
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from ingest import create_index
from retrieve import retrieve
from generate import generate_answer
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI(title="RAG from Scratch API")

# Load documents
with open("data/sample.txt", "r", encoding="utf-8") as f:
    text = f.read()

text_chunks = text.split("\n")

# Load embedding model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Create FAISS index
index, embeddings = create_index(text_chunks)


class Query(BaseModel):
    question: str


@app.get("/")
def home():
    return {"message": "RAG API running on port 8004 🚀"}


@app.post("/chat")
def chat(query: Query):
    # Retrieve relevant docs
    docs = retrieve(query.question, model, index, text_chunks)

    # Generate answer
    answer = generate_answer(query.question, "\n".join(docs))

    return {
        "question": query.question,
        "retrieved_docs": docs,
        "answer": answer
    }