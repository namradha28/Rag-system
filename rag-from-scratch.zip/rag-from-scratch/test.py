from openai import OpenAI
import os

# Using the Groq API key found in generate.py
GROQ_API_KEY = "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"

client = OpenAI(
    api_key=GROQ_API_KEY,
    base_url="https://api.groq.com/openai/v1"
)

response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[{"role":"user","content":"Say hello"}]
)

print(response.choices[0].message.content)