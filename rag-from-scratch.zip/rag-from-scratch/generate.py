from openai import OpenAI

client = OpenAI(
    api_key="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",
    base_url="https://api.groq.com/openai/v1"
)

def generate_answer(query, context):
    prompt = f"""
    Answer using the following context:
    {context}
    
    Question: {query}
    """
    
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role":"user","content":prompt}]
    )
    
    return response.choices[0].message.content