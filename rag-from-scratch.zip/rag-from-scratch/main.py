from sentence_transformers import SentenceTransformer
from ingest import create_index
from retrieve import retrieve
from generate import generate_answer

# Load data
with open("data/sample.txt") as f:
    text = f.read()

text_chunks = text.split("\n")

model = SentenceTransformer('all-MiniLM-L6-v2')
index, embeddings = create_index(text_chunks)

query = input("Ask something: ")

docs = retrieve(query, model, index, text_chunks)

answer = generate_answer(query, "\n".join(docs))

print("\nAnswer:", answer)